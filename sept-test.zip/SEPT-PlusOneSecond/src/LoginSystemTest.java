import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LoginSystemTest {

	
	LoginSystem test =new LoginSystem();
	@Before
	public void setUp() throws Exception {
	}

    @Test
	public void testLogin1() {
	test.login("admin","admin");
	assertEquals(1,test.getLoginCheck());
	}
    @Test
    public void testLogin2() {
    	test.login("ADMIN","ADMIN");
    	assertEquals(2,test.getLoginCheck());
    	}
    @Test
    public void testRegister1(){
    	test.Register("ADMIN", "ADMIN");
    	assertEquals(false,test.getregJunit());
    }
    @Test
    public void testRegister2(){
    	test.Register("JUNIT4","JUNIT4");
    	assertEquals(true,test.getregJunit());
    }

}
