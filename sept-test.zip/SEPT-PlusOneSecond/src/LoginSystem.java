import java.sql.*;
import java.util.Scanner;

public class LoginSystem {
	String loggedName;


	private static int loginCheck = 1;
	private static String inputLogUser;
	private static String inputLogPass;
	private static String inputUser;
	private static String inputPass;
	private static String inputPass2;
	private static Scanner keyboard = new Scanner(System.in);
	private static String pass = null;
	private static String user = null;
	private static int userId;
	private static int permission;
	private static boolean PassCheck = true;
	private static Connection LoginConn = null;
	private static int userCount;
	private static int userCount2;
	private static ResultSet rs = null;
	private static Statement st = null;
	private static Boolean regJunit;
	

	
	
	
	
	public static int loginmenu() {	
			

			
				System.out.println("---------------------------");
				System.out.println("Login");
				System.out.println("---------------------------");
				
				System.out.print("User ID: ");
				inputLogUser = keyboard.nextLine();
				
				System.out.print("Password: ");
				inputLogPass = keyboard.nextLine();
				
				login(inputLogUser,inputLogPass);

			return loginCheck;
			
			}
			
			public static void login(String inputLogUser,String inputLogPass){
				
				try{
					//Start functions 
				
				// Connection LoginConn = null;

					LoginConn = connection.connectDB();  //connect to the SQL
					
					 st = LoginConn.createStatement();  //create statement of it
								 
					 rs = st.executeQuery("SELECT * FROM USERS where USERNAME = \'" + inputLogUser + "\'");
					 // Query function 1(unsafe. easy to inject)
					while (rs.next()){ 
					 pass = rs.getString("PASSWORD");
					 user = rs.getString("USERNAME");
					 userId = rs.getInt("USER_ID");
					 permission = rs.getInt("PERMISSION");
					 
					}
					// get username and password 
					
					if ( user.equals(inputLogUser)&&pass.equals(inputLogPass)){
						//compare with database. have to same both.
						if(permission == 1){
							loginCheck = 2;
						}
						else if(permission == 2){
							loginCheck = 3;
						}
						System.out.println("Login Succesful");
						
						username(user);
						//user_id(userId);
						returnId = userId;
						
					}				
					}
									
				catch(Exception exc)
				{
					//if can not pass or something. throw a error.
					System.out.println("wrong username or password");
					loginCheck = 1;
				//exc.printStackTrace();	
				}
			}
	// to return who logged in. return to line 48 on TEST. variable on line 44. to define who's data going to take
	private static String returnName;
	public static String username(String Username){
		if (Username != null){
			returnName = Username;
		}
		else if(Username == null){
			
		}
	
		return returnName;
	}
	
	public static int returnId;
	
	public static int user_id(int UserId){
		if (UserId != 0){
			returnId = UserId;
		}
		return returnId;
	}
	
	
	public static int RegisterMenu(){
	//	int loginCheck = 1;
	
		System.out.println("---------------------------");
		System.out.println("Sign up");
		System.out.println("---------------------------");
		
		System.out.print("User ID: ");
		inputUser = keyboard.nextLine();
		
		
		while(PassCheck == true){
		System.out.print("Password: ");
		inputPass = keyboard.nextLine();
		
		System.out.print("Password again: ");
		inputPass2 = keyboard.nextLine();
		
		if(inputPass.equals(inputPass2)){
			PassCheck = false;
		}
		else{
			System.out.println("re-enter the password please.");
			PassCheck = true;
		}
		
		}
		Register(inputUser,inputPass);
		return loginCheck;
	}
	
	
		public static void Register(String inputUser,String inputPass){
			
		try{
		
			LoginConn = connection.connectDB();
			
			 st = LoginConn.createStatement();  //create statement of it
			 
			 rs = st.executeQuery("SELECT COUNT(USER_ID) FROM USERS");
			 
			 userCount = rs.getInt("COUNT(USER_ID)");
			 
			 userCount2 = userCount + 1;
		 // query type 2. more security than type 1. and more easy to write.
			 PreparedStatement rs = LoginConn.prepareStatement("INSERT INTO USERS(USERNAME,PASSWORD,USER_ID,PERMISSION) VALUES(?,?,?,1)");
			 rs.setString(1,inputUser);
		     rs.setString(2,inputPass);
		     rs.setInt(3,userCount2);
		     // excuteQuery for query. excuteUpdate for editing the database
		     rs.executeUpdate();
		     
		     PreparedStatement rs2 = LoginConn.prepareStatement("INSERT INTO DETAILS(USER_ID,FIRST_NAME,LAST_NAME,EMAIL,PHONE_NO,ADDRESS) VALUES(?,?,?,?,?,?)");
		     rs2.setInt(1, userCount2);
		     rs2.setString(2,null);
		     rs2.setString(3,null);
		     rs2.setString(4,null);
		     rs2.setString(5,null);
		     rs2.setString(6,null);
		     rs2.executeUpdate();
		     

			System.out.println("finished");
			loginCheck = 1;
			PassCheck = true;
			//LoginConn.close();
			regJunit=true;
			}
							
		catch(Exception exc)
		{
			System.out.println("Something went wrong.");
			 regJunit=false; 
			

		//exc.printStackTrace();	
		}

	}
	
	
	public static void LogOut(){
		loginCheck = 1;
	}

	public void setInputLogUser(String inputLogUser){
		this.inputLogUser = inputLogUser;
	}
	
	public void setInputLogPass(String inputLogPass){
		this.inputLogPass = inputLogPass;
	}
	
	public String getInputLogUser(){
		return inputLogUser;
	}
	
	public String getInputLogPass(){
		return inputLogPass;
	}
	
	public int getLoginCheck(){
		return loginCheck;
	}
	
	public Boolean getregJunit(){
		return regJunit;
	}
	
}
