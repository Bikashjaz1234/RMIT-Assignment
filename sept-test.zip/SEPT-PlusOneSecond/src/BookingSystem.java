
public class BookingSystem {
	public static void login(){
		//Login Function
	}
	
	public static void Register(){
		//Register Function
	}
	
	public static void LogOut(){
		//Logout function
	}
	
	public static void TestSubmit(){
		//This is a test class for testing submit by github
	}
}
