
public class MyDetails {
	public static void showDetails(){
		//Show Detail Function
	}
	
	public static void editDetails(){
		//Edit Detail Function
	}
}
