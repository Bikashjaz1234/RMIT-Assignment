import java.sql.*;
import java.util.Scanner;

public class Menu {
	
	private int loginCheck = 1 ;
	private Scanner keyboard = new Scanner(System.in);

	private int menuSelection;

    
	
	public void loginSelect(){
		
		while(loginCheck == 1){
		System.out.println("----------------------------------");
		System.out.println("Welcome to Customer Booking System");
		System.out.println("----------------------------------");
		System.out.println("1. Login");
		System.out.println("2. Register");
		System.out.println("----------------------------------");

		System.out.print("Enter an Option: ");
		menuSelection = keyboard.nextInt();
		//if you don't understand if and while. go kill you self
		if(menuSelection == 1){
			
			loginCheck = LoginSystem.loginmenu();
			if(loginCheck == 1){
				continue;
			}
			if(loginCheck == 2){
				displayCusMenu();
			}
			else if(loginCheck == 3){
				displayOwnMenu();
			}
		}
		else if(menuSelection == 2){
			LoginSystem.RegisterMenu();
		}
	}
	}
	
	

	public void displayCusMenu() {
		String reinfo = null; //initial the user's account.
		//displays all the options for the user to choose from
		System.out.println("---------------------------");
		System.out.println("Customer Booking System:");
		System.out.println("Currently logged as " + LoginSystem.username(reinfo)+ "ID: " + LoginSystem.returnId);
		System.out.println("---------------------------");
		System.out.println("1. Booking Management");
		System.out.println("2. Personal Details");
		System.out.println("3. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
		menuSelection = keyboard.nextInt();
		
		switch(menuSelection)
        {
            case 1:{
            	System.out.println("---------------------------");
        		System.out.println("Customer Booking System:");
        		System.out.println("Booking Management" );
        		System.out.println("---------------------------");
        		System.out.println("1. My bookings");
        		//System.out.println("2. Make a new booking");
        		System.out.println("3. Exit");
        		System.out.println("----------------------------");
        		System.out.print("Enter an Option: ");
        		menuSelection = keyboard.nextInt();
        		
        		switch(menuSelection)
                {
                    case 1:{
                  //  	MyBooking();
                		
                    }
                        break;
                    case 2:{
                  //  	NewBooking();
                    }
                    	break;
                    case 3:
                    	displayCusMenu();
                    	break;
                }
            }
                break;
            /*case 2:{
            	MyDetails.DisplayDetails();
            }*/
            //	break;
            case 3:
            	reinfo = null;
            	loginCheck = 1;
            	LoginSystem.LogOut();
            	System.out.println("You have sucsussful logged out");
            	loginSelect();
            	break;
        }
	}
	
	public void displayOwnMenu(){
		String reinfo = null; //initial the user's account.
		//displays all the options for the user to choose from
		System.out.println("---------------------------");
		System.out.println("Owner Booking System:");
		System.out.println("Currently logged as " + LoginSystem.username(reinfo)+ " ID: " + LoginSystem.returnId);
		System.out.println("---------------------------");
		System.out.println("1. Booking Management");
		System.out.println("2. User Management");
		System.out.println("3. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
		menuSelection = keyboard.nextInt();
		
		switch(menuSelection){
		case 1:{
			//OwnBookingManagement();
		}
		break;
		
        case 2:{
      //  	OwnUserManagement();
        }
        	break;
        	
        case 3:
        	reinfo = null;
        	loginCheck = 1;
        	LoginSystem.LogOut();
        	System.out.println("You have sucsussful logged out");
        	loginSelect();
        	break;
		}
		
			
	}
		
	
}
