#!/usr/bin/env sh

java GameServer & java ChatServer
