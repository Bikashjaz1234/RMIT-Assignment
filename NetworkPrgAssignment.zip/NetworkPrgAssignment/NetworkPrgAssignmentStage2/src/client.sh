#!/usr/bin/env sh

java GameClient
