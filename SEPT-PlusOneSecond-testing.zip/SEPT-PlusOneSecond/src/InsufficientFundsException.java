
public class InsufficientFundsException extends Exception{

	/*public static void message(String[] args){
	    int MessigeSize = 10;
		String message[]=new String[MessigeSize];
		message[1] = "asd";
		message[2] = "asdas";
		message[3] = "asdasasdasd";
	}*/
	String throwMessage;
	public InsufficientFundsException(String throwMessage){
		throwMessage = this.throwMessage;
	}
	public String toString(){
		 return throwMessage;
	}

	
}
