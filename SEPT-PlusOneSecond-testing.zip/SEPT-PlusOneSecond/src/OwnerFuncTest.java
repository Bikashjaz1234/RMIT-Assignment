import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class OwnerFuncTest {

	OwnerFunc test = new OwnerFunc();
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAddEmployeeSQL1() {
		try{
		test.AddEmployeeSQL("", "", "");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Employee's information is empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	
	@Test
	public void testAddEmployeeSQL2() {
		try{
		test.AddEmployeeSQL("Haven","", "");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Last name and phone number are empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	
	@Test
	public void testAddEmployeeSQL3() {
		try{
		test.AddEmployeeSQL("","Job", "");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "First name and phone number are empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	@Test
	public void testAddEmployeeSQL4() {
		try{
		test.AddEmployeeSQL("","","1234567890");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "First name and Last name are empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	@Test
	public void testAddEmployeeSQL5() {
		try{
		test.AddEmployeeSQL("","Job","1234567890");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "First name is empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	@Test
	public void testAddEmployeeSQL6() {
		try{
		test.AddEmployeeSQL("Haven","","1234567890");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Last name is empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
	@Test
	public void testAddEmployeeSQL7() {
		try{
		test.AddEmployeeSQL("Haven","Job","");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Phone number is empty.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		}
//	@Test
//	public void testAddEmployeeSQL8() {
//		try{
//		test.AddEmployeeSQL("Haven+","Job","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "First name is not allow contain special .";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL9() {
//		try{
//		test.AddEmployeeSQL("Haven-","Job","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "First name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL10() {
//		try{
//		test.AddEmployeeSQL("Haven(","Job","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "First name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL11() {
//		try{
//		test.AddEmployeeSQL("Haven)","Job","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "First name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL12() {
//		try{
//		test.AddEmployeeSQL("Haven","Job+","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "Last name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL13() {
//		try{
//		test.AddEmployeeSQL("Haven","Job-","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "Last name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL14() {
//		try{
//		test.AddEmployeeSQL("Haven","Job(","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "Last name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
//	@Test
//	public void testAddEmployeeSQL15() {
//		try{
//		test.AddEmployeeSQL("Haven","Job)","1234567890");
//		fail("Exception should appear");
//		}
//    	catch(Exception exc){
//    	String expected = "Last name is not allow contain special.";
//    	String acutal = exc.getMessage();
//    	assertEquals(expected,acutal);
//    	}
//		}
	
	
	
	@Test
	public void testAddEmployeeSQL() throws Exception{
		test.AddEmployeeSQL("Haven","Job","1234567890");
		assertEquals("Haven",test.getEmpFirst());
		assertEquals("Job",test.getEmpLast());
		assertEquals("1234567890",test.getEmpPhone());
	}


}
