import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyDetails extends Menu {
	
		private static Connection LoginConn = null;
		private static ResultSet rs = null;
		private static Statement st = null;
		private static int reId;
		private static String firstName;
		private static String lastName;
		private static String email;
		private static String phoneNo;
		private static String address;
		private static boolean passCheckC;
		private static String password;
		private static String username;
		private static int userIpt;
		private static boolean whileCheck;


		public static void DisplayDetails(){
			try{
				//Start functions 
			
			// Connection LoginConn = null;
				 LoginConn = connection.connectDB();  //connect to the SQL
				 st = LoginConn.createStatement();  //create statement of it
				 rs = st.executeQuery("SELECT * FROM DETAILS where USER_ID = " + LoginSystem.returnId );
				 // Query function 1(unsafe. easy to inject)
			//	while (rs.next()){ 
				 firstName = rs.getString("FIRST_NAME");
				 lastName = rs.getString("LAST_NAME");
				 email = rs.getString("EMAIL");
				 phoneNo = rs.getString("PHONE_NO");
				 address = rs.getString("ADDRESS");
			//	}
				 
				System.out.println("First name: " + firstName);
				System.out.println("Last name: " + lastName);
				System.out.println("email address: " + email);
				System.out.println("Phone number: " + phoneNo);
				System.out.println("Address: " + address);
			}
			catch(Exception e){
				e.printStackTrace();	
				
			}
		}
	public static Object editDetails(){
		//Edit Detail Function
		do{
			while(true){
		Scanner keyboard = new Scanner(System.in);
		System.out.println("---------------------------");
		System.out.println("Edit Detail");
		System.out.println("---------------------------");
		System.out.println("Please Input which Detail you wang to edit.(1-6)");
		System.out.println("1. password");
		System.out.println("2. First Name");
		System.out.println("3. Last Name");
		System.out.println("4. Phone number");
		System.out.println("5. Address");
		System.out.println("6. Quit");
		System.out.println("---------------------------");
		//userIpt = keyboard.nextInt();
		String Ipt = keyboard.nextLine();
		try{
			userIpt = Integer.valueOf(Ipt);
		    break;
			}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
    	}
		switch(userIpt){
			case 1:{
				Scanner iptPass = new Scanner(System.in);
				String inputPassEdit;
				String inputPassEdit2;
				passCheckC = true;
				System.out.println("Edit Password Function");
				while(passCheckC == true){
					System.out.print("Please input your new password: ");
					inputPassEdit = iptPass.nextLine();
					
					System.out.print("Password again: ");
					inputPassEdit2 = iptPass.nextLine();
					
					if(inputPassEdit.equals(inputPassEdit2)){
						passCheckC = false;
						
					}
					else{
						System.out.println("re-enter the password please.");
						passCheckC = true;
					}
					PasswordChange(inputPassEdit);
				}
				break;
			}
			case 2:
				Scanner iptFN = new Scanner(System.in);
				System.out.println("Edit First Name Function");
				String inputFirstName;
				System.out.print("Please input your first Name: ");
				inputFirstName = iptFN.nextLine();
				FirstNameChange(inputFirstName);
				break;
			case 3:
				Scanner iptLN = new Scanner(System.in);
				System.out.println("Edit Last Name Function");
				String inputLastName;
				System.out.print("Please input your Last Name: ");
				inputLastName = iptLN.nextLine();
				LastNameChange(inputLastName);
				break;
			case 4:
				Scanner iptNum = new Scanner(System.in);
				System.out.println("Edit Phone Number Function");
				int inputNumber;
				System.out.print("Please input your Phone Number: ");
				try{
				inputNumber = iptNum.nextInt();
				PhoneNumberChange(inputNumber);
				}
				catch (InputMismatchException e){
					System.out.println("Please only Input number.");
				}
				break;
			case 5:
				Scanner iptAddress = new Scanner(System.in);
				System.out.println("Edit Addres Function");
				String inputAddre;
				System.out.print("Please input your Address: ");
				inputAddre = iptAddress.nextLine();
				AddressChange(inputAddre);
				break;
			case 6:{
				System.out.println("Bye Bye");
				whileCheck = false;
				break;}
			case 7:
				System.out.println("You are Bad Girl!!");
				break;
			default:
				System.out.println("Invalid Input");
            	break;
		}
		return editDetails();
		
	}while(whileCheck = true);
	}
	
	public static void CheckDetails(){
		try{
			//Start functions 
		
		// Connection LoginConn = null;
			
			LoginConn = connection.connectDB();  //connect to the SQL
			
			 st = LoginConn.createStatement();  //create statement of it
			 
			 rs = st.executeQuery("SELECT * FROM DETAILS where USER_ID = " + LoginSystem.returnId );
			 // Query function 1(unsafe. easy to inject)
		//	while (rs.next()){ 
			 firstName = rs.getString("FIRST_NAME");
			 lastName = rs.getString("LAST_NAME");
			 email = rs.getString("EMAIL");
			 phoneNo = rs.getString("PHONE_NO");
			 address = rs.getString("ADDRESS");
		//	}
			 

	
		}
		catch(Exception e){
			e.printStackTrace();	
			
		}
		 if(firstName == null || lastName == null || email == null || phoneNo == null || address == null){
			 System.out.println("Your personal detail is not complete yet.");
			 System.out.println("Please fill out your personal details in My Details.");
			 if(firstName == null){
				 System.out.println("Your first name havn't signned yet.");
			 }
			 if(lastName == null){
				 System.out.println("Your last name havn't signned yet.");
			 }
			 if(email == null){
				 System.out.println("Your email havn't signned yet.");
			 }
			 if(phoneNo == null){
				 System.out.println("Your phoneNo havn't signned yet.");
			 }
			 if(address == null){
				 System.out.println("Your address havn't signned yet.");
			 }
			 
		 }
		 
	}
	
	public String getFirstName(){
		return firstName;
	}
	
	public String getLastName(){
		return lastName;
	}
	
	public String getEmail(){
		return email;
	}

	public String getPhoneNo(){
		return phoneNo;
	}
	
	public String getAddress(){
		return address;
	}
	
	public String getPassword(){
		try{
			LoginConn = connection.connectDB();
			 st = LoginConn.createStatement();  //create statement of it			 
			 rs = st.executeQuery("SELECT * FROM USERS where USER_ID = \'" + LoginSystem.returnId + "\'");			
			password = rs.getString("PASSWORD");			
		}
		catch(Exception exc){			
		}		
		return password;
	}
	
	public String getUsername(){
		try{
			LoginConn = connection.connectDB();
			 st = LoginConn.createStatement();  //create statement of it			 
			 rs = st.executeQuery("SELECT * FROM USERS where USER_ID = \'" + LoginSystem.returnId + "\'");			
			username = rs.getString("USERNAME");			
		}
		catch(Exception exc){	}		
		return username;
	}
	
	
	
	
	
	
	
	
	public static void PasswordChange(String password){
		try{
			LoginConn = connection.connectDB();
			PreparedStatement rs = LoginConn.prepareStatement("UPDATE USERS SET PASSWORD = ? WHERE USER_ID = ?" );
			rs.setString(1, password);
			rs.setInt(2, LoginSystem.returnId);
			rs.executeUpdate();
			System.out.println("Password changed");	
			
		}
		catch(Exception exc){
			System.out.println("Something went wrong when changing the password");
			
		}
		
	}
	
	public static void FirstNameChange(String firstName){
		try{
			LoginConn = connection.connectDB();		
			PreparedStatement rs = LoginConn.prepareStatement("UPDATE DETAILS SET FIRST_NAME = ? WHERE USER_ID = ?" );
			rs.setString(1, firstName);
			rs.setInt(2, LoginSystem.returnId);
			rs.executeUpdate();
			System.out.println("First Name changed");		
		}
		catch(Exception exc){
			System.out.println("Something went wrong when changing the First Name");
			exc.printStackTrace();
		}
		
	}
	
	public static void LastNameChange(String lastName){
		try{
			LoginConn = connection.connectDB();		
			PreparedStatement rs = LoginConn.prepareStatement("UPDATE DETAILS SET LAST_NAME = ? WHERE USER_ID = ?" );
			rs.setString(1, lastName);
			rs.setInt(2, LoginSystem.returnId);
			rs.executeUpdate();
			System.out.println("Last Name changed");		
		}
		catch(Exception exc){
			System.out.println("Something went wrong when changing the Last Name");
			
		}
		
	}
	
	public static void PhoneNumberChange(int phonenumber){
		try{
			LoginConn = connection.connectDB();		
			PreparedStatement rs = LoginConn.prepareStatement("UPDATE DETAILS SET PHONE_NO = ? WHERE USER_ID = ?" );
			rs.setInt(1, phonenumber);
			rs.setInt(2, LoginSystem.returnId);
			rs.executeUpdate();
			System.out.println("Phone Number changed");		
		}
		catch(Exception exc){
			System.out.println("Something went wrong when changing the Phone Number");
			
		}
		
	}
	
	public static void AddressChange(String address){
		try{
			LoginConn = connection.connectDB();		
			PreparedStatement rs = LoginConn.prepareStatement("UPDATE DETAILS SET ADDRESS = ? WHERE USER_ID = ?" );
			rs.setString(1, address);
			rs.setInt(2, LoginSystem.returnId);
			rs.executeUpdate();
			System.out.println("Phone Number changed");		
		}
		catch(Exception exc){
			System.out.println("Something went wrong when changing the Address");
			
		}
		
	}
	
	
}
