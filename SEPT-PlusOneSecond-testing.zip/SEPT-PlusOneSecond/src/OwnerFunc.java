import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class OwnerFunc {
	
	private static Connection LoginConn = null;
	private static ResultSet rs = null;
	private static Statement st = null;
	private static int empCount;
	private static Scanner keyboard = new Scanner(System.in);


	public static void AddEmployee(){
		

		String empFirst;
		String empLast;
		String empPhone;
		boolean inputCheck = true;
		while(inputCheck == true){
		System.out.println("---------------------------");
		System.out.println("Add new employee");
		System.out.println("---------------------------");
		
		while(true){
			try{
					System.out.println("Please input new employee's first name");
					empFirst = keyboard.nextLine();
					HandleException.UserFuncNameInputCheck1(empFirst);
					break;
			}
			catch(Exception e)
			{
				continue;
			}
		}
		while(true){
			try{
					System.out.println("Please input new employee's last name");
					empLast = keyboard.nextLine();
					HandleException.UserFuncNameInputCheck1(empLast);
					break;
				}
				catch(Exception e)
				{
					continue;
				}
			}
		while(true){
			try{
					System.out.println("Please input new employee's phone number");
					empPhone = keyboard.nextLine();
					HandleException.UserFuncPhoneInputCheck(empPhone);
					break;
			}	
			catch(Exception e)
			{
				continue;
			}
		}
		
		try{
			System.out.println("Starting to creat new empleyee");
			AddEmployeeSQL(empFirst,empLast,empPhone);
		}
		catch(Exception exc){
			System.out.println("something went wrong when creating new employee");
		//	exc.printStackTrace();
		}
		
			inputCheck = false;
			break;


		}
	/*	System.out.println("Do you wish to add this employee's working hours?");
		 System.out.println("1.yes");
		 System.out.println("2.I will do it later");
		 int userinput = keyboard.nextInt();
		 
		 if(userinput == 1){
			 //AddEmpTime();
		 }
		 else if(userinput == 2){
			
		 }
		*/
		
	}
	
	
	
	public static void AddEmployeeSQL(String empFirst, String empLast, String empPhone) throws Exception{
		
			//HandleException.UserFuncTestSQL(empFirst, empLast, empPhone);
		if(empFirst.equals("") && empLast.equals("") && empPhone.equals("")){
			throw new Exception("Employee's information is empty.");
		}
		if(empLast.equals("") && empPhone.equals(""))
		{
			throw new Exception("Last name and phone number are empty.");
		}
		if(empFirst.equals("") && empPhone.equals(""))
		{
			throw new Exception("First name and phone number are empty.");
		}		
		if(empFirst.equals("")  && empLast.equals("")){
			throw new Exception("First name and Last name are empty.");
		}
		if(empFirst.equals("")){
			throw new Exception("First name is empty.");
		}
		if(empLast.equals("")){
			throw new Exception("Last name is empty.");
		}
		if(empPhone.equals("")){
			throw new Exception("Phone number is empty.");
		}
		if(empFirst != null && empLast != null && empPhone != null){

			LoginConn = connection.connectDB();  //connect to the SQL
			
			st = LoginConn.createStatement();  //create statement of it

			rs = st.executeQuery("SELECT COUNT(EMP_UID) FROM EMPLOYEE");
			 
			empCount = rs.getInt("COUNT(EMP_UID)");
			
			empCount += 1;
			
			 PreparedStatement rs = LoginConn.prepareStatement("INSERT INTO EMPLOYEE(EMP_FIRST,EMP_LAST,EMP_PHONE,EMP_UID) VALUES(?,?,?,?)");
			 rs.setString(1, empFirst);
			 rs.setString(2, empLast);
			 rs.setString(3, empPhone);
			 rs.setInt(4, empCount);
			 rs.executeUpdate();
			 System.out.println("finished to add a new employee");

			
		}
			

	}
	
	public static void ViewEmployee(){
		try{
			 String empFirst;
			 String empLast;
			 String empPhone;
			 String empUid;
			//Start functions 
		
		// Connection LoginConn = null;
			 LoginConn = connection.connectDB();  //connect to the SQL
			 st = LoginConn.createStatement();  //create statement of it
			 rs = st.executeQuery("SELECT * FROM EMPLOYEE");
			 // Query function 1(unsafe. easy to inject)
			while (rs.next()){ 
			 empFirst = rs.getString("EMP_FIRST");
			 empLast = rs.getString("EMP_LAST");
			 empPhone = rs.getString("EMP_PHONE");
			 empUid = rs.getString("EMP_UID");
		//	
			 
			System.out.println("-------------------------------"); 
			System.out.println("First name: " + empFirst);
			System.out.println("Last name: " + empLast);
			System.out.println("Phone number: " + empPhone);
			System.out.println("Employee ID: " + empUid);
			}	
		}
		catch(Exception e){
			e.printStackTrace();	
			
		}
		
		
	}
	public static int getEmpCount(){
		return empCount;
	}
	
	public String getEmpFirst() throws SQLException{
		
		String empFirst = null;
		
			LoginConn = connection.connectDB();
			 st = LoginConn.createStatement();  //create statement of it			 
			 rs = st.executeQuery("SELECT * FROM EMPLOYEE where EMP_UID = \'" + empCount + "\'");			
		     empFirst = rs.getString("EMP_FIRST");							
		return empFirst;
}
	
	public String getEmpLast() throws SQLException{
		
		String empLast = null;
		

			LoginConn = connection.connectDB();
			 st = LoginConn.createStatement();  //create statement of it			 
			 rs = st.executeQuery("SELECT * FROM EMPLOYEE where EMP_UID = \'" + empCount + "\'");			
		     empLast = rs.getString("EMP_LAST");			
		     
		return empLast;
	}
	
	public String getEmpPhone() throws SQLException{
		
		String empPhone = null;
		
	
			LoginConn = connection.connectDB();
			 st = LoginConn.createStatement();  //create statement of it			 
			 rs = st.executeQuery("SELECT * FROM EMPLOYEE where EMP_UID = \'" + empCount + "\'");			
		     empPhone = rs.getString("EMP_PHONE");			
	
		return empPhone;
	}

	

}
