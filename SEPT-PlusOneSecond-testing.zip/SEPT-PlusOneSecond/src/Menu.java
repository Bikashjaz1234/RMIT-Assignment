import java.sql.*;
import java.util.Scanner;

public class Menu {
	
	private int loginCheck = 1 ;
	private Scanner keyboard = new Scanner(System.in);

	private int menuSelection;

    
	
	public void loginSelect() throws Exception{
		
		while(loginCheck == 1){
		System.out.println("----------------------------------");
		System.out.println("Welcome to Customer Booking System");
		System.out.println("----------------------------------");
		System.out.println("1. Login");
		System.out.println("2. Register");
		System.out.println("----------------------------------");

		System.out.print("Enter an Option: ");
		String menuIpt = keyboard.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
		}
		
		
		//if you don't understand if and while. go kill you self
		if(menuSelection == 1){
			
			loginCheck = LoginSystem.loginmenu();
			if(loginCheck == 1){
				continue;
			}
			if(loginCheck == 2){
				displayCusMenu();
			}
			else if(loginCheck == 3){
				displayOwnMenu();
			}
		}
		else if(menuSelection == 2){
			LoginSystem.RegisterMenu();
		}
		else{
			continue;
		}
		
	}
	}
	
	

	public void displayCusMenu() throws Exception {
		String reinfo = null; //initial the user's account.
		//displays all the options for the user to choose from
		MyDetails.CheckDetails();
		while(true){
			while(true){
		System.out.println("---------------------------");
		System.out.println("Customer Booking System:");
		System.out.println("Currently logged as " + LoginSystem.username(reinfo)+ "ID: " + LoginSystem.returnId);
		System.out.println("---------------------------");
		System.out.println("1. Booking Management");
		System.out.println("2. Personal Details");
		System.out.println("3. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
	//	menuSelection = keyboard.nextInt();
		String menuIpt = keyboard.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		    break;
			}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
    	}
		
		switch(menuSelection)
        {
            case 1:{
            	while(true){
            	System.out.println("---------------------------");
        		System.out.println("Customer Booking System:");
        		System.out.println("Booking Management" );
        		System.out.println("---------------------------");
        		System.out.println("1. View avaliable time");
        		//System.out.println("2. Make a new booking");
        		System.out.println("3. Exit");
        		System.out.println("----------------------------");
        		System.out.print("Enter an Option: ");
        	//	menuSelection = keyboard.nextInt();
        		String menuIpt = keyboard.nextLine();
        		try{
        		    menuSelection = Integer.valueOf(menuIpt);
        		    break;
        			}
        		catch (NumberFormatException nfe){
        			System.out.println("Invalid Input");
        			}
            	}
        		switch(menuSelection)
                {
                    case 1:{
                  //  	MyBooking();
                		
                    }
                        break;
                    case 2:{
                  //  	NewBooking();
                    }
                    	break;
                    case 3:
                    	displayCusMenu();
                    	break;
                }
            }
                break;
            case 2:{
            	while(true){
            	System.out.println("---------------------------");
        		System.out.println("Customer Details System:");
        		System.out.println("---------------------------");
        		System.out.println("1. My Details");
        		System.out.println("2. Edit Details");
        		System.out.println("3. Exit");
        		System.out.println("----------------------------");
        		System.out.print("Enter an Option: ");
        	//	menuSelection = keyboard.nextInt();
        		String menuIpt = keyboard.nextLine();
        		try{
        		    menuSelection = Integer.valueOf(menuIpt);
        		    break;
        			}
        		catch (NumberFormatException nfe){
        			System.out.println("Invalid Input");
        			}
            	}
            	
        		switch(menuSelection)
                {
                    case 1:{
                    	MyDetails.DisplayDetails();
                    	continue;
                    }
                    
                        
                    case 2:{
                    	MyDetails.editDetails();
                    	continue;
                    }
                   
                    case 3:
                    	displayCusMenu();
                    	break;
                }
        		
            	
            }
            	break;
            case 3:
            	reinfo = null;
            	loginCheck = 1;
            	LoginSystem.LogOut();
            	System.out.println("You have sucsussful logged out");
            	loginSelect();
            	break;
        }
	 }
	}
	
	public void displayOwnMenu() throws Exception{
		String reinfo = null; //initial the user's account.
		//displays all the options for the user to choose from
		while(true){
			while(true){
		System.out.println("---------------------------");
		System.out.println("Owner Booking System:");
		System.out.println("Currently logged as " + LoginSystem.username(reinfo)+ " ID: " + LoginSystem.returnId);
		System.out.println("---------------------------");
		System.out.println("1. Timetable Management");
		System.out.println("2. User Management");
		System.out.println("3. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
	//	menuSelection = keyboard.nextInt();
		String menuIpt = keyboard.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		    break;
			}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
    	}
		
		switch(menuSelection){
		case 1:{
			OwnTimetableManagement();
			continue;
		}	
        case 2:{
        	OwnerUserManagement();
        	continue;
        }       	
        case 3:
        	reinfo = null;
        	loginCheck = 1;
        	LoginSystem.LogOut();
        	System.out.println("You have sucsussful logged out");
        	loginSelect();
        	break;
		}
		
	 }
	}
		
	public void OwnerUserManagement() throws Exception{
		while(true){
			while(true){
		System.out.println("---------------------------");
		System.out.println("Owner User Management System:");
		System.out.println("---------------------------");
		System.out.println("1. Add a new employee");
		System.out.println("2. Edit a employee");
		System.out.println("3. View all employee");
		System.out.println("4. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
	//	menuSelection = keyboard.nextInt();
		String menuIpt = keyboard.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		    break;
			}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
    	}
		switch(menuSelection){
		case 1:{
			OwnerFunc.AddEmployee();
			continue;
		}
	//	break;
		
        case 2:{
        	
        }
        	break;
        case 3:{
        	OwnerFunc.ViewEmployee();
        	continue;
        }
        case 4:{
        	displayOwnMenu();
        	break;
        }
	
	  }
	 }
	}

	public void OwnTimetableManagement() throws Exception{
		while(true){
			while(true){
		System.out.println("---------------------------");
		System.out.println("Owner Timetable Management System:");
		System.out.println("---------------------------");
		System.out.println("1. View a employee's timetable");
		System.out.println("2. Edit a employee's timetable");
		System.out.println("3. View a time shift timetable");
		System.out.println("4. Exit");
		System.out.println("----------------------------");
		
		System.out.print("Enter an Option: ");
	//	menuSelection = keyboard.nextInt();
		String menuIpt = keyboard.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		    break;
			}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
    	}
		
		switch(menuSelection){
		case 1:{
			TimetableFunc.SelectEmpUid();
			continue;
		}
		
		
        case 2:{
        	TimetableFunc.Editmenu();
        }
        //	break;
        case 3:{

        }
        case 4:{
        	displayOwnMenu();
        	break;
        }
	  }
		
	}
   }
	
}
