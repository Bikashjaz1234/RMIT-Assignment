import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TimetableFunc {
	private static Connection LoginConn = null;
	private static ResultSet rs = null;
	private static ResultSet rs2 = null;

	private static Statement st = null;
	static int[] weekdays = new int[7];
	static int[][] timetable = new int[7][12];
	
	// timetable[x][y] which x is the whole list of 1 day
	
	// timetable[x][y] when y=0 it will record weekdays
	
	// timetable[x][y] while y from 1 to 11 is recorded time T0800 to T1800

	static String weekdaysName;
	static int dateCount;
	static String first;
	static String last;
	private static int menuSelection;
	
	
	public static void SelectEmpUid(){
		Scanner keyboard = new Scanner(System.in);

		System.out.print("Please Employee's UID: ");
		int id = keyboard.nextInt();
		ViewEmpTimetable(id);
		
	}
	public static void Editmenu(){
		Scanner scan = new Scanner(System.in);
		
		while(true){
		System.out.println("----------------------------------");
		System.out.println("Welcome to EditTimetable System");
		System.out.println("----------------------------------");
		System.out.println("1. Add time");
		System.out.println("2. Cancel time");
		System.out.println("----------------------------------");

		System.out.print("Enter an Option: ");
		String menuIpt = scan.nextLine();
		try{
		    menuSelection = Integer.valueOf(menuIpt);
		}
		catch (NumberFormatException nfe){
			System.out.println("Invalid Input");
			}
		switch(menuSelection)
        {
            case 1:{
            try{
               AddTimemenu();
               break;
            }
            catch(Exception e)
            {continue;}
            }
            
            case 2:{
            try{
               CancelTimemenu();
               break;
            }
            catch(Exception e)
            {continue;}
		}
		}
	}
	}
	
	public static void weekdaysDef(int weekdays){
		switch(weekdays){
 		case 1:{
 			weekdaysName = "Mon";
 			break;
 		}
 		case 2:{
 			weekdaysName = "Tue";
 			break;
 		}
 		case 3:{
 			weekdaysName = "Wed";
 			break;
 		}
 		case 4:{
 			weekdaysName = "Thu";
 			break;
 		}
 		case 5:{
 			weekdaysName = "Fri";
 			break;
 		}
 		case 6:{
 			weekdaysName = "Sat";
 			break;
 		}
 		case 7:{
 			weekdaysName = "Sun";
 			break;
 		}
 		
 		
 		}
		
	}
	public static void ViewEmpTimetable(int empId){
		try{
		LoginConn = connection.connectDB();  //connect to the SQL
		 st = LoginConn.createStatement();  //create statement of it
		 
		 rs = st.executeQuery("SELECT * FROM TIMETABLE WHERE EMP_UID = " + empId );
		 
		 	int i = 0;
		 	
		 	while(rs.next()){

		 		int x = 0;
		 		timetable[i][x] = rs.getInt("WEEKDAYS");
		 		x++;
		 		timetable[i][x] = rs.getInt("T0800");
		 		x++;
		 		timetable[i][x] = rs.getInt("T0900");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1000");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1100");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1200");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1300");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1400");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1500");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1600");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1700");
		 		x++;
		 		timetable[i][x] = rs.getInt("T1800");
		 			
		 		i++;
		 		dateCount = i;
		 		
		 	}
			 rs2 = st.executeQuery("SELECT * FROM EMPLOYEE WHERE EMP_UID = " + empId);
			 first = rs2.getString("EMP_FIRST");
			 last = rs2.getString("EMP_LAST");
		 	
		 	System.out.println("You are viewing employee "+first+" "+last);
		 	System.out.println("|Weekdays  |08:00   |09:00   |10:00   |11:00   |12:00   |13:00   |14:00   |15:00   |16:00   |17:00   |18:00");
		 	for(int y = 0; y< dateCount;y++){
		 		weekdaysDef(timetable[y][0]);
		 		System.out.print("|"+ weekdaysName);
		 		
		 		for(int z = 1; z< 12; z++){
		 		System.out.print("       |" + timetable[y][z]);
		 		}
		 		System.out.println();
		 	}
		 
		}
		catch(Exception exc){
			//System.out.print("Something went wrong when display timetable.");
			exc.printStackTrace();
		}
	}
	
	
    public static void AddTimemenu() throws Exception{
    	
    	
    	int TarDay;
    	int TarBegTime;
    	int TarEndTime;
    	String QuitCheck;
		Scanner keyboard = new Scanner(System.in);		
		System.out.print("Please Enter Employee's UID: ");
		int id = keyboard.nextInt();
		ViewEmpTimetable(id);
		
		while(true)	
		{
		
		System.out.println("Please Enter day.(from '1' to '7')");
		TarDay = keyboard.nextInt();
		System.out.println("Please Enter begin time end time.(from '8' to '18')");
		TarBegTime = keyboard.nextInt();
		System.out.println("Please Enter end time.(from '8' to '18')");
		TarEndTime = keyboard.nextInt();
		
		try{
		AddTime(TarDay,TarBegTime,TarEndTime);
		}
		catch(Exception exc){
			continue;
		}
	 	for(int y = 0; y< dateCount;y++){
	 		weekdaysDef(timetable[y][0]);
	 		System.out.print("|"+ weekdaysName);
	 		
	 		for(int z = 1; z< 12; z++){
	 		System.out.print("       |" + timetable[y][z]);
	 		}
	 		System.out.println("");
	 	}
	 	
	 	System.out.println("If you want to quit Enter 'E'.");
	 	
	 	Scanner scan = new Scanner(System.in);
	 	QuitCheck = scan.nextLine();
	 	if(QuitCheck.equals("E"))
	 	{
	 		System.out.println("Do you want to save?.(Y/N)");
	 		QuitCheck = keyboard.nextLine();
	 		if(QuitCheck.equals("Y"))
	 		{
//	 			UploadTime(id);
	 			break;
	 			}
	 		}
	 	}
		}
    
    
    public static void CancelTimemenu() throws Exception{
    	
    	
    	int TarDay;
    	int TarBegTime;
    	int TarEndTime;
    	String QuitCheck;
		Scanner keyboard = new Scanner(System.in);		
		System.out.print("Please Enter Employee's UID: ");
		int id = keyboard.nextInt();
		ViewEmpTimetable(id);
		
		while(true)	
		{
		
		System.out.println("Please Enter day.(from '1' to '7')");
		TarDay = keyboard.nextInt();
		System.out.println("Please Enter begin time end time.(from '8' to '18')");
		TarBegTime = keyboard.nextInt();
		System.out.println("Please Enter end time.(from '8' to '18')");
		TarEndTime = keyboard.nextInt();
		
		try{
		CancelTime(TarDay,TarBegTime,TarEndTime);
		}
		catch(Exception exc){
			continue;
		}
	 	for(int y = 0; y< dateCount;y++){
	 		weekdaysDef(timetable[y][0]);
	 		System.out.print("|"+ weekdaysName);
	 		
	 		for(int z = 1; z< 12; z++){
	 		System.out.print("       |" + timetable[y][z]);
	 		}
	 		System.out.println("");
	 	}
	 	
	 	System.out.println("If you want to quit Enter 'E'.");
	 	
	 	Scanner scan = new Scanner(System.in);
	 	QuitCheck = scan.nextLine();
	 	if(QuitCheck.equals("E"))
	 	{
	 		System.out.println("Do you want to save?.(Y/N)");
	 		QuitCheck = keyboard.nextLine();
	 		if(QuitCheck.equals("Y"))
	 		{
//	 			UploadTime(id);
	 			break;
	 			}
	 		}
	 	}
		}
    
    

    
    
    
    public static void AddTime(int day,int BegTime,int EndTime) throws Exception{
    	if(1<day||day>7)
    	{
    		System.out.println("Day can not smller than 1 or over 7");
    		throw new Exception("Day can not smller than 1 or over 7");
    	}
    	if(BegTime<8||BegTime>18)
    	{
    		System.out.println("Begin time can not smller than 8 or over 18");
    		throw new Exception("Begin time can not smller than 8 or over 18");
    	}
    	if(EndTime<8||EndTime>18)
    	{
    		System.out.println("End time can not smller than 8 or over 18");
    		throw new Exception("End time can not smller than 8 or over 18");
    	}
    	if(BegTime>EndTime)
    	{
    		System.out.println("Begin time should bigger than End time");
    		throw new Exception("Begin time should bigger than End time");
    	}
    	
    	if(BegTime==EndTime)
    	{
    		timetable[day-1][BegTime]=1;
    	}
    	
    	for(int i=BegTime-7;i<=EndTime-7;i++)
    	{
    		timetable[day-1][i]=1;
    	}
    }
    
    public static void CancelTime(int day,int BegTime,int EndTime) throws Exception{
    	if(1<day||day>7)
    	{
    		System.out.println("Day can not smller than 1 or over 7");
    		throw new Exception("Day can not smller than 1 or over 7");
    	}
    	if(BegTime<8||BegTime>18)
    	{
    		System.out.println("Begin time can not smller than 8 or over 18");
    		throw new Exception("Begin time can not smller than 8 or over 18");
    	}
    	if(EndTime<8||EndTime>18)
    	{
    		System.out.println("End time can not smller than 8 or over 18");
    		throw new Exception("End time can not smller than 8 or over 18");
    	}
    	if(BegTime>EndTime)
    	{
    		System.out.println("Begin time should bigger than End time");
    		throw new Exception("Begin time should bigger than End time");
    	}
    	
    	if(BegTime==EndTime)
    	{
    		timetable[day-1][BegTime]=0;
    	}
    	
    	for(int i=BegTime-7;i<=EndTime-7;i++)
    	{
    		timetable[day-1][i]=0;
    	}
    }
    
    public static void UploadTime(int TarId){
    	
    }
	
	
	
	
	
	public static String getWeekdaysName(){
		return weekdaysName;
	}
}
