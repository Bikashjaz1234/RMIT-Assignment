import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LoginSystemTest {

	
	LoginSystem test =new LoginSystem();
	@Before
	public void setUp() throws Exception {
	}

    @Test
	public void testLogin1() {
    	
    	try{
        	test.login("admin","admin");
        	fail("Exception should be throw");
        	}
        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
	}
    
    @Test
    public void testLogin2() {
    	test.login("ADMIN","ADMIN");
    	assertEquals(2,test.getLoginCheck());
    	}
    
    @Test
    public void testLogin3() {
        test.login("123456","123456");
        assertEquals(2,test.getLoginCheck());
    	}
    
    @Test
    public void testLogin4() {
    	
    	try{
        	test.login("aDmIn","aDmIn");
        	fail("Exception should be throw");
        	}	
        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    @Test
    public void testLogin5() {
    	
    	try{
        	test.login("abcde+","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    @Test
    public void testLogin6() {
    	try{
        	test.login("a b c","a b c");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    @Test
    public void testLogin7() {
    	
    	try{
        	test.login("abcde-","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    @Test
    public void testLogin8() {
    	
    	try{
        	test.login("abcde(","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    @Test
    public void testLogin9() {
    	
    	try{
        	test.login("abcde)","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "wrong username or password";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    
    
    
    
    @Test
    public void testRegister1(){
    	
    	try{
        	test.Register("ADMIN","ADMIN");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    }
    
    @Test
    public void testRegister2(){
    	test.Register("JUNIT4","JUNIT4");
    	assertEquals(true,test.getregJunit());
    }
    
    @Test
    public void testRegister3() {
    	test.Register("123456","123456");
    	assertEquals(true,test.getregJunit());
    	}
    @Test
    public void testRegister4() {
       	try{
        	test.Register("aDmIn","aDmiN");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    @Test
    public void testRegister5() {
    	test.Register("a1b2c3","a1b2c3");
    	assertEquals(true,test.getregJunit());
    	}
    
    @Test
    public void testRegister6() {
       	try{
        	test.Register("a b c","a b c");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    @Test
    public void testRegister7() {
    	try{
        	test.Register("012345678901234567890","012345678901234567890");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    
    @Test
    public void testRegister8() {
    	try{
        	test.Register("abcde+","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    @Test
    public void testRegister9() {
    	try{
        	test.Register("abcde-","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    
    public void testRegister10() {
    	try{
        	test.Register("abcde(","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    public void testRegister11() {
    	try{
        	test.Register("abcde)","a1b2c3");
        	fail("Exception should be throw");
        	}

        	catch(Exception exc){
        	String expected = "Something went wrong.";
        	String acutal = exc.getMessage();
        	assertEquals(expected,acutal);
        	}
    	}
    	
    

}
