
public class HandleException {
	private static String  regWrong = "^[a-zA-Z0-9]+$";	
	private static String regNumOnly = "^[0-9]+$";
	private static String regLetOnly = "^[a-zA-Z]+$";

	public  static void UserNameInputCheck(String userInput) throws Exception {
	      if(userInput.length()<= 3||userInput.length()>=17)
	      {		         
	    	  System.out.println("Sorry, user name length is not permit");
	          throw new Exception("Sorry, user name length is not permit");
	      }	
	      else if(userInput.matches(regWrong)==false){
	    	  System.out.println("Sorry, Only String available");
	          throw new Exception("Sorry, Only String available");
	      }

	}
	public static void PasswordInputCheck(String userInput) throws Exception {
	      if(userInput.length()<= 5||userInput.length()>=17)
	      {
	          System.out.println("Sorry, password length is not permit");

	    	  throw new Exception("Sorry, password length is not permit");
	      }	
	      else if(userInput.matches(regWrong)==true){
	          System.out.println("Sorry, password format is not permit");

	    	  throw new Exception("Sorry, password format is not permit");

	      }
	      
	      
	}

	public static void UserFuncNameInputCheck1(String userInput) throws Exception{
		if(userInput.length()<= 2||userInput.length()>=17)
	      {		         
	    	  System.out.println("Sorry, first name length is not permit");
	          throw new Exception("Sorry, first name length is not permit");
	      }	
	      if(userInput.matches(regLetOnly)==false){
	    	  System.out.println("Sorry, Only can input letters");
	          throw new Exception("Sorry, Only can input letters");
	      }
	}
	
	public static void UserFuncPhoneInputCheck(String userInput) throws Exception{
		if(userInput.length() <= 5|| userInput.length() >= 15){
			System.out.println("Sorry, Phone number length is not permit");
			throw new Exception("Sorry, Phone number length is not permit");
		}
		else if(userInput.matches(regNumOnly) == false){
			System.out.println("Sorry, Phone number only allowed numbers input");
			throw new Exception("Sorry, Phone number only allowed numbers input");
	
		}
	}
	
	public static void UserFuncTestSQL(String empFirst, String empLast,String empPhone) throws Exception{
		if(empFirst.equals("") && empLast.equals("") && empPhone.equals("")){
			throw new Exception("Employee's information is empty.");
		}

		if(empLast.equals("") && empPhone.equals(""))
		{
			throw new Exception("Last name and phone number are empty");
		}

		if(empFirst.equals("") && empPhone.equals(""))
		{
			throw new Exception("First name and phone number are empty.");
		}		

		if(empFirst.equals("")  && empLast.equals("")){
			throw new Exception("First name and phone number are empty.");
		}

		if(empFirst.equals("")){
			throw new Exception("First name is empty.");
		}

		if(empLast.equals("")){
			throw new Exception("Last name is empty.");
		}

		if(empPhone.equals("")){
			throw new Exception("Phone number is empty");
		}
	}
	
}
