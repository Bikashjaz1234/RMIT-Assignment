import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MyDetailsTest {

	MyDetails test = new MyDetails();
	
	@Before
	public void setUp() throws Exception {
		LoginSystem.returnId = 0;
	}

	@Test
	public void testDisplayDetails1() {
		LoginSystem.returnId = 1;
		test.DisplayDetails();
		assertEquals("ZANG",test.getFirstName());
		assertEquals("LIU",test.getLastName());
		assertEquals("123@HOTMAIL.COM",test.getEmail());
		assertEquals("432666666",test.getPhoneNo());
		assertEquals("66 6ST 222",test.getAddress());
	}
	
	@Test
	public void testDisplayDetails2() {
		LoginSystem.returnId = 2;
		test.DisplayDetails();
		assertEquals(null,test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	
	@Test
	public void testDisplayDetails3() {
		LoginSystem.returnId = 3;
		test.DisplayDetails();
		assertEquals("a",test.getFirstName());
		assertEquals(null,test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	
	@Test
	public void testDisplayDetails4() {
		LoginSystem.returnId = 4;
		test.DisplayDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals(null,test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	
	@Test
	public void testDisplayDetails5() {
		LoginSystem.returnId = 5;
		test.DisplayDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals(null,test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	
	@Test
	public void testDisplayDetails6() {
		LoginSystem.returnId = 6;
		test.DisplayDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals(null,test.getAddress());
	}
	
	@Test
	public void testDisplayDetails7() {
		LoginSystem.returnId = 7;
		test.DisplayDetails();
		assertEquals(null,test.getFirstName());
		assertEquals(null,test.getLastName());
		assertEquals(null,test.getEmail());
		assertEquals(null,test.getPhoneNo());
		assertEquals(null,test.getAddress());
	}
	
	
	
	@Test
	public void testCheckDetails1() {
		LoginSystem.returnId = 1;
		test.CheckDetails();
		assertEquals("ZANG",test.getFirstName());
		assertEquals("LIU",test.getLastName());
		assertEquals("123@HOTMAIL.COM",test.getEmail());
		assertEquals("432666666",test.getPhoneNo());
		assertEquals("66 6ST 222",test.getAddress());
	}
	
	@Test
	public void testCheckDetails2() {
		LoginSystem.returnId = 2;
		test.CheckDetails();
		assertEquals(null,test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	@Test
	public void testCheckDetails3() {
		LoginSystem.returnId = 3;
		test.CheckDetails();
		assertEquals("a",test.getFirstName());
		assertEquals(null,test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	@Test
	public void testCheckDetails4() {
		LoginSystem.returnId = 4;
		test.CheckDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals(null,test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	@Test
	public void testCheckDetails5() {
		LoginSystem.returnId = 5;
		test.CheckDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals(null,test.getPhoneNo());
		assertEquals("a",test.getAddress());
	}
	@Test
	public void testCheckDetails6() {
		LoginSystem.returnId = 6;
		test.CheckDetails();
		assertEquals("a",test.getFirstName());
		assertEquals("a",test.getLastName());
		assertEquals("a",test.getEmail());
		assertEquals("a",test.getPhoneNo());
		assertEquals(null,test.getAddress());
	}
	
	@Test
	public void testCheckDetails7() {
		LoginSystem.returnId = 7;
		test.CheckDetails();
		assertEquals(null,test.getFirstName());
		assertEquals(null,test.getLastName());
		assertEquals(null,test.getEmail());
		assertEquals(null,test.getPhoneNo());
		assertEquals(null,test.getAddress());
	}
	
	@Test
	public void testPasswordchange1(){
		
		test.PasswordChange("a1b2c3d4");
		assertEquals("a1b2c3d4",test.getPassword());
		}
	
	@Test
	public void testPasswordchange2(){
		
		try{
		test.PasswordChange("aaaaaaaaaaaaaaaaa");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPasswordchange3(){
		
		try{
		test.PasswordChange("aaaaaaa");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPasswordchange4(){
		
		try{
		test.PasswordChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPasswordchange5(){
		
		try{
		test.PasswordChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPasswordchange6(){
		
		try{
		test.PasswordChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPasswordchange7(){
		
		try{
		test.PasswordChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}
		
		}
	@Test
	public void testPasswordchange8(){
		
		try{
		test.PasswordChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the password.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}

	@Test
	public void testFirstnamechange1(){
		
		test.FirstNameChange("a1b2c3d4");
		assertEquals("a1b2c3d4",test.getFirstName());
		}
	
	@Test
	public void testFirstnamechange2(){
		
		try{
		test.FirstNameChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the First Name.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	
	@Test
	public void testLastNamechange1(){
		
		test.LastNameChange("a1b2c3d4");
		assertEquals("a1b2c3d4",test.getLastName());
		}
	
	@Test
	public void testLastnamechange2(){
		
		try{
		test.LastNameChange("a");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the Last Name.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testPhoneNumberchange1(){
		
		test.PhoneNumberChange(1234567890);
		assertEquals(1234567890,test.getPhoneNo());
		}
	
	@Test
	public void testPhoneNumberchange2(){
		
		try{
		test.PhoneNumberChange(1234567890);
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the Phone Number.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	@Test
	public void testAddressChange1(){
		
		test.AddressChange("Street");
		assertEquals("Steet",test.getPhoneNo());
		}
	
	@Test
	public void testAddressChange2(){
		
		try{
		test.AddressChange("dadsada");
		fail("Exception should appear");
		}
    	catch(Exception exc){
    	String expected = "Something went wrong when changing the Address.";
    	String acutal = exc.getMessage();
    	assertEquals(expected,acutal);
    	}	
		}
	
	
	
	
}
	
	
	
	
	
