import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TimetableFuncTest {
    TimetableFunc test = new TimetableFunc();
    
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testWeekdaysDef1() {
		test.weekdaysDef(1);
		assertEquals("Mon",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef2() {
		test.weekdaysDef(2);
		assertEquals("Tue",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef3() {
		test.weekdaysDef(3);
		assertEquals("Wed",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef4() {
		test.weekdaysDef(4);
		assertEquals("Thu",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef5() {
		test.weekdaysDef(5);
		assertEquals("Fri",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef6() {
		test.weekdaysDef(6);
		assertEquals("Sat",test.getWeekdaysName());
	}
	
	@Test
	public void testWeekdaysDef7() {
		test.weekdaysDef(7);
		assertEquals("Sun",test.getWeekdaysName());
	}
	
	
	@Test
	public void testWeekdaysDef8() {
		try{
		test.weekdaysDef(8);
		fail("Exception should appear");
		}
		catch(Exception exc){
	    	String expected = "Invalid Input";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);	
		}
	}
	@Test
	public void testViewEmpTimetable1() {
		try{
			TimetableFunc.ViewEmpTimetable(1);
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testViewEmpTimetable2() {
		try{
			TimetableFunc.ViewEmpTimetable(-1);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testViewEmpTimetable3() {
		try{
			TimetableFunc.ViewEmpTimetable(100000000);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testViewEmpTimetable4() {
		try{
			TimetableFunc.ViewEmpTimetable(0);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testViewEmpTimetable5() {
		try{
			TimetableFunc.ViewEmpTimetable(-0);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testViewEmpTimetable6() {
		try{
			TimetableFunc.ViewEmpTimetable(-1000000);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime1() {
		try{
			TimetableFunc.AddTime(1, 8, 9);
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime2() {
		try{
			TimetableFunc.AddTime(8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime3() {
		try{
			TimetableFunc.AddTime(8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime4() {
		try{
			TimetableFunc.AddTime(1, -8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}

	@Test
	public void testAddTime5() {
		try{
			TimetableFunc.AddTime(1, 28, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime6() {
		try{
			TimetableFunc.AddTime(1, 7, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime7() {
		try{
			TimetableFunc.AddTime(1, 8, -9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "End time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime8() {
		try{
			TimetableFunc.AddTime(1, 8, 29);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "End time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime9() {
		try{
			TimetableFunc.AddTime(1, 14, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time should bigger than End time";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testAddTime10() {
		try{
			TimetableFunc.AddTime(-8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime1() {
		try{
			TimetableFunc.CancelTime(1, 8, 9);
		}
		catch(Exception exc){
			String expected = "Something went wrong when display timetable.";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime2() {
		try{
			TimetableFunc.CancelTime(8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime3() {
		try{
			TimetableFunc.CancelTime(8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime4() {
		try{
			TimetableFunc.CancelTime(1, -8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}

	@Test
	public void testCancelTime5() {
		try{
			TimetableFunc.CancelTime(1, 28, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime6() {
		try{
			TimetableFunc.CancelTime(1, 7, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime7() {
		try{
			TimetableFunc.CancelTime(1, 8, -9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "End time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime8() {
		try{
			TimetableFunc.CancelTime(1, 8, 29);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "End time can not smller than 8 or over 18";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime9() {
		try{
			TimetableFunc.CancelTime(1, 14, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Begin time should bigger than End time";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	@Test
	public void testCancelTime10() {
		try{
			TimetableFunc.CancelTime(-8, 8, 9);
			fail("Exception should appear");
		}
		catch(Exception exc){
			String expected = "Day can not smller than 1 or over 7";
	    	String acutal = exc.getMessage();
	    	assertEquals(expected,acutal);
		}
	}
	
	
//	@Test
//	public void testViewEmpTimetable() {
//		try{
//		test.ViewEmpTimetable(-1);
//		fail("Exception should appear");
//		}
//		catch(Exception exc){
//	    	String expected = "Invalid Input";
//	    	String acutal = exc.getMessage();
//	    	assertEquals(expected,acutal);	
//		}
//	}

}
