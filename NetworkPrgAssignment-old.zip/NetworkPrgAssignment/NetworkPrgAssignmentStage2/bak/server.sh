#!/usr/bin/env sh

java ChatServer
