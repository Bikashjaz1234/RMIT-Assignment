import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.sql.Date;
import java.text.SimpleDateFormat;


class ServerThread extends Thread {
	public static ArrayList<Socket> mClients = new ArrayList<Socket>();
	private ArrayList<String> mMsgQueue = new ArrayList<String>();
	public static int clientNum = 0;
	public static Player[] player = new Player[30];
	
	private String usrName;
	private int generNum;
	private int guessNum;
	
	public synchronized void addClient(Socket aClientSocket) {
		mClients.add(aClientSocket);
		clientNum++;
		
	}

	public synchronized void deleteClient(Socket aClientSock) {
		int i = mClients.indexOf(aClientSock);
		if (i != -1) {
			mClients.remove(i);
			try {
				aClientSock.close();
				clientNum--;
			} catch (IOException ioe) {
			}
		}
	}

	public synchronized void dispatchMsg(Socket aSocket, String aMsg) {
		
		int serverRandom = (int) (Math.random() * 3);
		String[] parts = aMsg.split("[*]");
		usrName = parts[0];
		generNum = Integer.valueOf(parts[1]);
		guessNum = Integer.valueOf(parts[2]);
		int player1 = -1;
		int player2 = -1;
		int player3 = -1;
		if (clientNum == 1){
			if (player[1] == null){
				player[1] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 1, 1;");
			}else if(player[2] == null){
				player[2] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 1, 2;");
			}else{
				player[3]= new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 1, 3;");
			}
			//System.out.println("The first name is: " + player[1].getName());
		}else if (clientNum == 2){
			if (player[1] == null){
				player[1] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 2, 1;");
			}else if(player[2] == null){
				player[2] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 2, 2;");
			}else{
				player[3]= new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 2, 3;");
			}
			//System.out.println("The 2 name is: " + player[2].getName());
		}else if (clientNum >= 3){
			if (player[1] == null){
				player[1] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 3, 1;");
				System.out.println("username is " + usrName);
			}else if(player[2] == null){
				player[2] = new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 3, 2;");
				System.out.println("username is " + usrName);
			}else{
				player[3]= new Player(usrName, generNum, guessNum, serverRandom);
				System.out.println("sent 3, 3;");
			}
		}
		
		aMsg = aMsg + "\n\r";
		mMsgQueue.add(aMsg);
		System.out.println("The Client Num: " + clientNum);
		if (clientNum >= 3){
			if(player[1] != null && player[2] != null && player[3] != null){
			
			player1 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[1].getGuess());
			player2 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[2].getGuess());
			player3 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[3].getGuess());
			System.out.println("The server generate number is:" + player[1].getSerNum());
			System.out.println("The 1 generate number is:" + player[1].getGenerate());
			System.out.println("The 2 generate number is:" + player[2].getGenerate());
			System.out.println("The 3 generate number is:" + player[3].getGenerate());
			System.out.println("The sum is:" + (player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()));
			}
			
		}else if (clientNum == 2){
			System.out.println("I will wait 5 sec;");
			player1 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[1].getGuess());
			player2 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[2].getGuess());
		}else if (clientNum == 1){
			System.out.println("I will wait 10 sec;");
			player1 = Math.abs((player[1].getGenerate() + player[2].getGenerate() + player[3].getGenerate() + player[1].getSerNum()) - player[1].getGuess());
		}
		//notify();
		if (clientNum >= 3){
			if(player[1] != null && player[2] != null && player[3] != null){
				checkWinnerForThree(player1, player2, player3);
			}
		}else if(clientNum == 2){
			if(player[1] != null && player[2] != null){
				checkWinnerForTwo(player1, player2);
			}
		}
	}

	private synchronized String getNextMsgFromQueue() throws InterruptedException {
		while (mMsgQueue.size() == 0)
			wait();
		String msg = mMsgQueue.get(0);
		mMsgQueue.remove(0);
		System.out.println("Msg is: " + msg);
		
		return msg;

	}

	public synchronized void sendMsgToAllClients(String aMsg) {
		for (int i = 0; i < mClients.size(); i++) {
			Socket socket = mClients.get(i);
			try {
				java.io.OutputStream out = socket.getOutputStream();
				out.write(aMsg.getBytes());
				out.flush();
			} catch (IOException ioe) {
				deleteClient(socket);
			}
		}
	}
	
	public synchronized void sendMsgToWaitClients(String aMsg) {
		for (int i = 3; i < mClients.size(); i++) {
			Socket socket = mClients.get(i);
			try {
				java.io.OutputStream out = socket.getOutputStream();
				out.write(aMsg.getBytes());
				out.flush();
			} catch (IOException ioe) {
				deleteClient(socket);
			}
		}
	}
	
	public synchronized void sendMsgToCurrClients(String aMsg) {
			int currClientNum = mClients.size();
			Socket socket = mClients.get(currClientNum);
			try {
				java.io.OutputStream out = socket.getOutputStream();
				out.write(aMsg.getBytes());
				out.flush();
			} catch (IOException ioe) {
				deleteClient(socket);
			}
		
	}

	public void run() {
		try {
			while (true) {
				String msg = getNextMsgFromQueue();
				sendMsgToAllClients(msg);
			}
		} catch (InterruptedException ie) {
		}
	}
	
	public void checkWinnerForThree(int player1, int player2, int player3){
		if (player1 == player2 && player2 == player3){
			System.out.println("Size is123: " + mClients.size());
			String result = "Server Message: The winner is Player1, Player2 and Player3!";
			String welCome = "Welcome to the Game, You can play the game now!";
			sendMsgToAllClients(result);
			notify();
			sendMsgToWaitClients(welCome);
			notify();
			initPlayer();
			initMclient();
			System.out.println("Server Message: The winner is Player1, Player2 and Player3!");
			System.out.println("Size is: " + mClients.size());
			
		}else if(player1 == player2 && player1 < player3){
			String result = "Server Message: The winner is Player1 and Player2!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Player1 and Player2!");
		}else if(player2 == player3 && player3 < player1){
			String result = "Server Message: The winner is Player2 and Player3!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Player2 and Player3!");
		}else if(player1 == player3 && player3 < player2){
			String result = "Server Message: The winner is Player1 and Player3!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Player1 and Player3!");
		}else if (player1 < player2 && player1 < player3){
			String result = "Server Message: The winner is Playerr1!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Playerr1!");
		}else if(player2 < player1 && player2 < player3){
			String result = "Server Message: The winner is Playerr2!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Playerr2!");
		}else if(player3 < player1 && player3 < player2){
			String result = "Server Message: The winner is Playerr3!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Playerr3!");
		}
	}
	
	public void checkWinnerForTwo(int player1, int player2){
		if (player1 == player2){
			String result = "Server Message: The winner is Player1 and Player2!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Player1 and Player2!");
		}else if (player1 < player2){
			String result = "Server Message: The winner is Playerr1!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Playerr1!");
		}else if(player2 < player1){
			String result = "Server Message: The winner is Playerr2!";
			sendMsgToAllClients(result);
			notify();
			initPlayer();
			System.out.println("Server Message: The winner is Playerr2!");
		}
	}
	
	public void initPlayer(){
		for (int i = 0; i <= 10; i++){
			player[i] = null;
		}
	}
	
	public void initMclient(){
		for (int i = 0; i < mClients.size(); i++){
			mClients.remove(i);
		}
	}
	
	public static int currClientNum(){
		int currClientnum = mClients.size();
		return currClientnum;
	}
	
}
