#!/usr/bin/env sh

java ChatClient
