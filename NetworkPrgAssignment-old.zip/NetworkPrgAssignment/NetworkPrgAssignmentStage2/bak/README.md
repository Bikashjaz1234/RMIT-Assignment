Aplicativo de CHAT desenvolvido em Sistemas Distribuidos


Alunos:
- André Arlindo Costa Portes
- Bruno Leandro
- Denis Leite
- Felipe Sales
- Junio Célio
- Leandro Sobrinho Júnior
- Luiz Carlos Pereira
- Marlon Castro de Souza


Instruções:
Para compilar o aplicativo, use o Makefile disponível, digitando make na linha de comando.

Após isso, inicie o servidor com o comando: ./server.sh

Para abrir clientes, execute o comando: ./client.sh

Para enviar mensagens privadas, digite sua mensagem assim:

nome_do_destinatario: mensagem

Onde nome_do_destinatario deve ser trocado pelo nome do sujeito que receberá a mensagem.
