import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;


public class ChatClient {
	public static final String SERVER_HOSTNAME = "localhost";
	public static final int SERVER_PORT = 6666;
	public static int iptTime = 0;
	public static Player[] player;
	static int generate = 0;
	static int guess = 0;
	static boolean regFlag = true;
	static int msgLen = 0;
	
	public static void main(String[] args) throws IOException {
		BufferedReader in = null;
		PrintWriter out = null;
		Socket socket = null;
		ServerThread.clientNum++;
	   
	    
		try {
			socket = new Socket(SERVER_HOSTNAME, SERVER_PORT);
			in = new BufferedReader(
				new InputStreamReader(socket.getInputStream())
			);

			out = new PrintWriter(
				new OutputStreamWriter(socket.getOutputStream())
			);

			System.out.println("Connect to " + SERVER_HOSTNAME + ":" + SERVER_PORT);
			

		} catch (IOException ioe) {
			System.err.println("Cannot connect to " + SERVER_HOSTNAME + ":" + SERVER_PORT);
			System.exit(1);
		}
		String name = null;;
		String usrIpt;
		int menuIpt = -1;
		String messageChk = in.readLine();
		messageChk = messageChk.replaceAll("(\\r|\\n)", "");
		msgLen = messageChk.length();
		if (messageChk.length() != 0){
			System.out.println(messageChk);
		}
		while(regFlag){
			System.out.println("Game Menu");
			System.out.println("1. Register");
			System.out.println("2. Begin Game");
			System.out.println("3. Exit");
			Scanner ins = new Scanner(System.in);
			usrIpt = ins.nextLine();
			
			try{
				menuIpt = Integer.valueOf(usrIpt);
			}
			catch (NumberFormatException nfe){
				//System.out.println("Invalid Input");
			}
			
			switch(menuIpt){
			case 1:
				Scanner ipt = new Scanner(System.in);
				System.out.print("Please input your name: ");
				name = ipt.nextLine();
				//player[playerNumber] = new Player(name, generate, guess);
				break;
			case 2:
				if (name != null && msgLen < 80){
					Sender sender = new Sender(out, name);
					sender.start();
					try {
						String message;
						System.out.println("I'm tHERE2.");
						while ((message = in.readLine()) != null) {
							message = message.replaceAll("(\\r|\\n)", "");
							if (message.length() == 0) {
								continue;
							}
							iptTime++;
							//System.out.println(message);
							if (message.contains("!")){
								String[] parts = message.split("!");
								System.out.println(parts[0]);
								System.out.println("Bye Bye! See you next time!");
								//socket.close();
								System.exit(0);
							}
							//System.out.println(message);
							System.out.print("> ");
						}
					} catch (IOException ioe) {
						System.err.println("Error Happened.");
					}
					break;
				}else if (msgLen >= 80){
					System.out.println("The game is not finish, please waiting!");
					String welcomeChk = in.readLine();
					welcomeChk = welcomeChk.replaceAll("(\\r|\\n)", "");
					if (welcomeChk.contains("!")){
						String[] welParts = welcomeChk.split("!");
						if (welParts[1].length() == 46){
							iptTime = 0;
							System.out.println("I'm tHERE.");
							Sender sender = new Sender(out, name);
							sender.start();
							try {
								String message;
								while ((message = in.readLine()) != null) {
									message = message.replaceAll("(\\r|\\n)", "");
									if (message.length() == 0) {
										continue;
									}
									iptTime++;
									//System.out.println(message);
									if (message.contains("!")){
										String[] parts = message.split("!");
										System.out.println(parts[0]);
										System.out.println("Bye Bye! See you next time!");
										System.exit(0);
									}
									//System.out.println(message);
									System.out.print("> ");
								}
							} catch (IOException ioe) {
								System.err.println("Error Happened.");
							}
						}
					}
					break;
				}else{
					menuIpt = -1;
					System.out.println("You do not register.");
					System.out.println("");
					break;
				}
			case 3:
				System.out.println("Bye Bye!");
				System.exit(0);
			default:
				menuIpt = -1;
				System.out.println("Invalid input!");
				System.out.println("");
				break;
			}
		}
	}

}


