import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Sender extends Thread {
	private PrintWriter mOut;
	private String name;

	public Sender(PrintWriter aOut, String name) {
		mOut = aOut;
		this.name = name;
	}

	public void run() {
		try {
			BufferedReader in = new BufferedReader(
				new InputStreamReader(System.in)
			);
			System.out.println("Welcome to Guessing Game!");
			System.out.println("Rule:");
			System.out.println("1. The server generate a number 0 and 2");
			System.out.println("2. Every client will input a number between 0 and 2");
			System.out.println("3. You need to guess the sum of the input");
			System.out.println("4. The people who is the closest, he will win!");
			System.out.println("Please input the number that you generate.");
			int guessNumber = -1;
			int genNumber = -1;
			String sendMsg = null;
			boolean checkFlg = false;
			boolean checkNum = true;
			
			while (!isInterrupted()) {
				System.out.println("sender start3!");
				System.out.print("> ");
				String message = in.readLine();
				System.out.println("UserIPt is: " + message);
				System.out.println("UserTime is: " + ChatClient.iptTime);
				// For the generate the number
				if (ChatClient.iptTime == 0 || ChatClient.iptTime == 2){
					System.out.println("sender start4!");
					try{
						genNumber = Integer.valueOf(message);
						//sendMsg = genNumber + "*" + name + "*" + ChatClient.iptTime;
						checkFlg = true;
					}catch (NumberFormatException nfe) {
						System.out.println("Invalid Input");
					}
					if (genNumber >= 0 || genNumber <= 2){
						checkNum = true;
					}else{
						System.out.println("The number that you input should between 0 and 2");
					}
					if (checkFlg == true && checkNum == true){
						
						System.out.println("**********************************");
						System.out.println("The number that you generate is: " + genNumber);
						System.out.println("This message only you are visable");
						System.out.println("**********************************");
						System.out.println("Please input the number that you guess. The number should between 0 and 2");
						ChatClient.iptTime++;
						//mOut.println(sendMsg);
						//mOut.flush();
					}
				}else if(ChatClient.iptTime == 1 || ChatClient.iptTime == 3){
					// For the guess the number
					try{
						guessNumber = Integer.valueOf(message);
						sendMsg = name + "*" + genNumber + "*" + guessNumber + "*" + ChatClient.iptTime;
						checkFlg = true;
						//System.out.println(sendMsg);
					}catch (NumberFormatException nfe) {
						System.out.println("Invalid Input");
					}
					
					if (checkFlg == true && checkNum == true){
						
						System.out.println("**********************************");
						System.out.println("The number that you guess is: " + guessNumber);
						System.out.println("This message only you are visable");
						System.out.println("**********************************");
						mOut.println(sendMsg);
						mOut.flush();
					}else{
						System.out.println("You already finish guessing.");
					}
				}
			}
		} catch (IOException ioe) {
		}
	}
}
