import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {

	public static final int LISTENING_PORT = 6666;
	public static int MAX_GAME = 3;
	
	public static void main(String[] args) throws IOException, InterruptedException {
		ServerSocket serverSocket = new ServerSocket(LISTENING_PORT);
		System.out.println("The Server's port is: " + serverSocket.getLocalPort());
		ServerThread dispatcher = new ServerThread();
		dispatcher.start();

		while (true) {
				Socket clientSocket = serverSocket.accept();
				PrintWriter toClient = new PrintWriter(clientSocket.getOutputStream(), true);
				BufferedReader fromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				System.out.println("Client size is:" + (ServerThread.mClients.size() + 1));
				int connClient = ServerThread.mClients.size() + 1;
				if (connClient > MAX_GAME){
					toClient.println("There already has 3 people in the game, you need to wait until they finish the game! You are the " + (ServerThread.mClients.size() + 1) + " people!");
				}else{
					toClient.println("Welcome to the Game! You are the " + (ServerThread.mClients.size() + 1) + " people!");
				}
				ClientListener clientListener = new ClientListener(clientSocket, dispatcher);
				dispatcher.addClient(clientSocket);
				System.out.println("Client Num is:" + ServerThread.clientNum);
				clientListener.start();

		}
	}
}

